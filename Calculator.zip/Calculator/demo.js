
var buttons = document.getElementsByClassName('button');
var display = document.getElementById('display');
var operand1 = 0;
var operand2 = null;
var operator = null;
var x = document.getElementById("myAudio");
// function playAudio(){
//     x.play();
// }

for(var i=0;i<buttons.length;i++){
    buttons[i].addEventListener('click',function(){
        var value = this.getAttribute('data-value');

        if(value=='+'){
            operator = '+';
            operand1 = parseFloat(display.textContent);
            display.innerText = operator;
        }else if(value=='='){
            
            operand2 = parseFloat(display.textContent);
            display.innerText = operand2;
            if(operator == '%'){
                 var result =  eval(operand1+" "+'/'+" "+'10000');
                 display.innerText = eval(result+" "+'*'+" "+operand2);
                 
                  
            }else{
                display.innerText = eval(operand1+" "+operator+" "+operand2);
            }
        }else if(value=='-'){
            operator = '-';
            operand1 = parseFloat(display.textContent);
            display.innerText = operator;
        }else if(value=='*'){
            operator = '*';
            operand1 = parseFloat(display.textContent);
            display.innerText = operator;
        }else if(value=='/'){
            operator = '/';
            operand1 = parseFloat(display.textContent);
            display.innerText = operator;
        }else if(value=='AC'){
            
            display.innerText=null;
        }else if(value=='%'){
            operator = '%';
            operand1 = parseFloat(display.textContent);
            operand1 *= '100';
            display.innerText = operator;
        }else if(value=='+/-'){
            
            display.innerText +='-';
            operand1 = parseFloat(display.textContent);
            
        }else if(value=='.'){
            
            display.innerText +='.';
            operand1 = parseFloat(display.textContent);
            
        } else{
            if(display.innerText==operator){
                display.innerText = value;
            }else{
            display.innerText += value;
            }
        }
    });
}